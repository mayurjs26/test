import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productperformance',
  templateUrl: './productperformance.component.html',
  styleUrls: ['./productperformance.component.css']
})
export class ProductperformanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
