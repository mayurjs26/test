import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductperformanceComponent } from './productperformance.component';

describe('ProductperformanceComponent', () => {
  let component: ProductperformanceComponent;
  let fixture: ComponentFixture<ProductperformanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductperformanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductperformanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
