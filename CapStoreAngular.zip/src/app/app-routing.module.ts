import { AllordersComponent } from './allorders/allorders.component';
import { AnalysisComponent } from './analysis/analysis.component';
import { MerchantperformanceComponent } from './merchantperformance/merchantperformance.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductdisplayComponent } from './productdisplay/productdisplay.component';
import { SoldproductgraphComponent } from './soldproductgraph/soldproductgraph.component';

const routes: Routes = [
{path: '', redirectTo: '', pathMatch: 'full'},
{path: 'analysis/productDisplay', component: ProductdisplayComponent,pathMatch: 'full'},
{path: 'analysis/merchantPerformance', component: MerchantperformanceComponent, pathMatch: 'full'},
{path: 'analysis', component: AnalysisComponent, pathMatch: 'full'},
{path:'graph',component: SoldproductgraphComponent,pathMatch:'full'},
{path:'allorders',component: AllordersComponent,pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {


}
