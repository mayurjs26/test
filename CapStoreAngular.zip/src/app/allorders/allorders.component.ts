import { ServiceService } from './../service.service';
import { Component, OnInit } from '@angular/core';
import { Order } from '../model/Order';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-allorders',
  templateUrl: './allorders.component.html',
  styleUrls: ['./allorders.component.css']
})
export class AllordersComponent implements OnInit {

  dataSource;
  order: Order[];

  constructor(private service:ServiceService) { }

  ngOnInit() {
  }

  getallOrders(){
    this.service.getAllOrder().subscribe(
      result => {this.order = result;
        this.dataSource = new MatTableDataSource(result);
      }

    )
  }

  displayedColumns = ['id', 'date','amount'];
}
