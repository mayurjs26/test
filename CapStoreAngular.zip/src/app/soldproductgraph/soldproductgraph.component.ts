import { MostView } from "./../model/MostView";
import { ServiceService } from "./../service.service";
import { Component, OnInit, ViewChild } from "@angular/core";
import { ChartOptions, ChartType, ChartDataSets } from "chart.js";
import {Label } from "ng2-charts";


@Component({
  selector: "app-soldproductgraph",
  templateUrl: "./soldproductgraph.component.html",
  styleUrls: ["./soldproductgraph.component.css"]
})
export class SoldproductgraphComponent implements OnInit {
//  @ViewChild(BaseChartDirective) baseChart: BaseChartDirective;

  mostview: MostView[] = [];
  soldcount = [];
  productName = [];

  public barChartOptions:ChartOptions = {
    responsive: true
  };
  public barChartType:ChartType = "bar";
  public barChartLegend = true;
  public barChartLabels:Label[] = [];
  public barChartData:ChartDataSets[] = [];
  constructor(private service: ServiceService) {}

  ngOnInit() {
    this.getmostview();
  }

  getmostview() {
    this.service.getmostviewed().subscribe(result => {
      this.mostview = result;
      console.log(this.mostview);
      this.soldcount = this.mostview.map(a => a.soldCount);
      console.log(this.soldcount);
      this.productName = this.mostview.map(a => a.productFromMostView.name);
      console.log(this.productName);
      this.barChartLabels = this.productName;
      this.barChartData = this.soldcount;
    });
  }
}
