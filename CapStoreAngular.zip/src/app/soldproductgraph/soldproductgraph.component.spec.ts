import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SoldproductgraphComponent } from './soldproductgraph.component';

describe('SoldproductgraphComponent', () => {
  let component: SoldproductgraphComponent;
  let fixture: ComponentFixture<SoldproductgraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SoldproductgraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoldproductgraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
