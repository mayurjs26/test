import { AnalysisComponent } from './analysis/analysis.component';

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ProductdisplayComponent } from './productdisplay/productdisplay.component';
import { MerchantperformanceComponent } from './merchantperformance/merchantperformance.component';
import { ProductperformanceComponent } from './productperformance/productperformance.component';
import { MaterialModule } from './material.module';
import { HttpClientModule } from '@angular/common/http';
import { ChartsModule } from 'ng2-charts';
import { SoldproductgraphComponent } from './soldproductgraph/soldproductgraph.component';
import { AllordersComponent } from './allorders/allorders.component';


@NgModule({
  declarations: [
    AppComponent,
    ProductdisplayComponent,
    MerchantperformanceComponent,
    ProductperformanceComponent,
    AnalysisComponent,
    SoldproductgraphComponent,
    AllordersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule, HttpClientModule,
    FormsModule,ChartsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
