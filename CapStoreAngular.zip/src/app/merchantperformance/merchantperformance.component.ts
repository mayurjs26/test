import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchantperformance',
  templateUrl: './merchantperformance.component.html',
  styleUrls: ['./merchantperformance.component.css']
})
export class MerchantperformanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
