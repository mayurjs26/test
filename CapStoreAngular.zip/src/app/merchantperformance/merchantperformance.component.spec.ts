import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantperformanceComponent } from './merchantperformance.component';

describe('MerchantperformanceComponent', () => {
  let component: MerchantperformanceComponent;
  let fixture: ComponentFixture<MerchantperformanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantperformanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantperformanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
