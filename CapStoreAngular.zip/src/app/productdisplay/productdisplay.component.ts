import { ServiceService } from './../service.service';
import { Inventory } from './../model/Inventory';
import { Component, OnInit, Input } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { Product } from '../model/Product';
import { Merchant } from '../model/Merchant';

@Component({
  selector: 'app-productdisplay',
  templateUrl: './productdisplay.component.html',
  styleUrls: ['./productdisplay.component.css']
})
export class ProductdisplayComponent implements OnInit {
  //inventory:Inventory[] = [];
  dataSource;
  merchantid:string;
  product:Product[] = [];
  @Input() merchant :Merchant;


  constructor(private service : ServiceService) {
this.merchant = new Merchant();
   }

  ngOnInit() {
//this.getproductbymerchant();
  }


  // getall(){
  //   this.service.getall().subscribe(
  //     result => {this.inventory = result;
  //       this.dataSource = new MatTableDataSource(result);
  //     },
  //     error => {console.log(error)}

  //   )

  // }

  getproductbymerchant(){
    console.log(this.merchant.id);
    this.service.getproductbymerchant(this.merchant.id).subscribe(
      result =>{this.product = result;
        console.log(this.product);
      this.dataSource = new MatTableDataSource(result);}
    )
}

// displayedColumns = ['inventory_id', 'product_id', 'merchant_id', 'description','product_actual_price','product_discount_price','quantity'];

displayedColumns = ['id', 'catId','name','brand'];
}
