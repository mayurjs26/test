package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@Controller
public class HelloController {

	@Autowired
	private ProductRepo repo;
	
	@GetMapping("/hi")
	public String sayHello() {
		return "HI HELLO";
	}
	
	@PostMapping("/add")
	public String saveProduct(@RequestParam("name") String name,@RequestParam("price")double price) {
		Product p = new Product();
		p.setName(name);
		p.setPrice(price);
		repo.saveProduct(p);
		 return "Saved";
	}
	
	@GetMapping(path="/get",produces="application/json")
	public Product saySomething(@RequestParam("id") int id) {
		Product p = repo.get(id);
		return p;
	}
	
	
	@GetMapping("/getAll")
	public List<Product> getAll(){
		return repo.getAll();
	}
	
	@GetMapping(path="/delete")
	public void delete(@RequestParam("i") int i) {
		repo.delete(i);
	}
	
	@RequestMapping(name="/login",method=RequestMethod.GET)
	public String login() {
		return "login";
	}
}
