package com.cg.rest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Scope("session")
@Controller
@RequestMapping("user")
public class TestController {

}
