package com.cg.entity;

import javax.persistence.Entity;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
public class Login {
	
	@NotEmpty(message="Username empty")
	@Size(min=4,max=8,message="Min 4 and Max 8 characters required")
	private String userName;
	@NotEmpty(message="Password Cant be Empty")
	private String password;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
