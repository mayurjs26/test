/**
 * 
 */
package com.cg.repo;

import java.util.List;

import com.cg.entity.Trainee;

/**
 * @author mayur
 *
 */
public interface TraineeRepo {
	public void addTrainee(Trainee trainee);

	public void deleteTrainee(int id);

	public void modifyTrainee(Trainee trainee);

	public Trainee findTraineeById(int id);

	public List<Trainee> findAllTrainee();

}
