export class User {
 userId: any;
 userFirstName: any;
 userLastName: any;
 userContact: any;
 userEmail: any;
 userBloodGroup: any;
 uDOB:any;
 userAddress:any;

}
