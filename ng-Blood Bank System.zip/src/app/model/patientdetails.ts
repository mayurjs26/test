export class Patient {
    id: number;
    firstName: string;
    lastName: string;
    patientContact: string;
    patientBloodGroup: string;
    patientHospitalLoc: string;
    pDOB:String;
    patientEmail:String;
}
