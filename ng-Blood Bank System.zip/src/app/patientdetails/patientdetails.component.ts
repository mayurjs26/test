import { Component, OnInit, Input } from '@angular/core';
import { Patient } from '../model/patientdetails';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patientdetails',
  templateUrl: './patientdetails.component.html',
  styleUrls: ['./patientdetails.component.css']
})
export class PatientdetailsComponent implements OnInit {
  @Input('contact') contactval;
  patientdetailsArr: Patient[] = [];
  patientArr: Patient[] = [];
  allEmailId: [];
  trial: any;
  patient: Patient;
  constructor(private service: ServiceService, private router: Router) {
    this.patient = new Patient();

  }


  ngOnInit() {

  }
  addPatient() {
    this.service.addPatient(this.patient).subscribe(
      data => {
        console.log(data);
        this.router.navigate(['/admin']);

      });
  }
  Validation() {
    /*if (this.patient.patientContact.invalid && (this.patient.patientContact.dirty || this.patient.patientContact.touched)) {
      
     }*/
    // else {
    this.addPatient();
    //}
  }

}
