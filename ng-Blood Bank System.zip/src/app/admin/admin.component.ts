import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Patient } from '../model/patientdetails';
import { ServiceService } from '../service.service';
import { User } from '../model/user';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  patientArr: Patient[] = [];
  patient: Patient;
  userArray : User[] = [];
  userArr: User[] = [];
  user: User;
  patientsData: any = [];
  userData: any = [];
  Aminus: number = 0;
  Aplus: number = 0;
  Bminus: number = 0;
  Bplus: number = 0;
  Ominus: number = 0;
  Oplus: number = 0;
  ABminus: number = 0;
  ABplus: number = 0;
  count:number=0;

  constructor(private router: Router, private service: ServiceService) {
   
  }

  ngOnInit() {
    this.getPatients();
    //this.getUsers();
    this.service.getUser().subscribe( res => {
      this.userArr = res;
      JSON.stringify(this.userArr);
      console.log(this.userArr);
      this.userArr.forEach(element => {
        console.log(this.userArray)
        if(element.userBloodGroup === 'A-'){
          this.Aminus++;
        }
        else if(element.userBloodGroup === 'B+'){
          this.Bplus++;
        }
        else if(element.userBloodGroup === 'A+'){
          this.Aplus++;
        }
        else if(element.userBloodGroup === 'AB+'){
          this.ABplus++;
        }
        else if(element.userBloodGroup === 'AB-'){
          this.ABminus++;
        }
        else if(element.userBloodGroup === 'A+'){
          this.Aplus++;
        }
        else if(element.userBloodGroup === 'B-'){
          this.Bminus++;
        }
        else if(element.userBloodGroup === 'O+'){
          this.Oplus++;
        }
        else if(element.userBloodGroup === 'O-'){
          this.Ominus++;
        }

      });

    });
}
getPatients() {
  console.log(this.patientArr);
  this.service.getPatient().subscribe( res => {
    this.patientArr = (res) ;
    JSON.stringify(this.patientArr);
    console.log(this.patientArr);
    return this.patientArr;
  });
}

getUsers() {
  this.service.getUser().subscribe( res => {
    this.userArr = res;
    JSON.stringify(this.userArr);
    console.log(this.userArr);
  });
}
notifButtonClick(bloodgroup:string){
  console.log(bloodgroup)
  if(bloodgroup === 'A-'){
    if(this.Aminus>0){
      alert("Blood Group Matched")
      this.Aminus--
    }
    else
    alert("Blood Group Not Matched")
  }
  else if(bloodgroup === 'B+'){
    if(this.Bplus>0){
      alert("Blood Group Matched")
      this.Bplus--
    }
    else
    alert("Blood Group Not Matched")
  }
  else if(bloodgroup === 'A+'){
    if(this.Aplus>0){
      alert("Blood Group Matched")
      this.Aplus--
    }
    else
    alert("Blood Group Not Matched")
  }
  else if(bloodgroup === 'AB+'){
    if(this.ABplus>0){
      alert("Blood Group Matched")
      this.ABplus--
    }
    else
    alert("Blood Group Not Matched")
  }
  else if(bloodgroup === 'AB-'){
    if(this.ABminus>0){
      alert("Blood Group Matched")
      this.ABminus--
    }
    else
    alert("Blood Group Not Matched")
  }
  else if(bloodgroup === 'A+'){
    if(this.Aplus>0){
      alert("Blood Group Matched")
      this.Aplus--
    }
    else
    alert("Blood Group Not Matched")
  }
  else if(bloodgroup === 'B-'){
    if(this.Bminus>0){
      alert("Blood Group Matched")
      this.Bminus--
    }
    else
    alert("Blood Group Not Matched")
  }
  else if(bloodgroup === 'O+'){
    if(this.Oplus>0){
      alert("Blood Group Matched")
      this.Oplus--
    }
    else
    alert("Blood Group Not Matched")
  }
  else if(bloodgroup === 'O-'){
    if(this.Ominus>0){
      alert("Blood Group Matched")
      this.Ominus--
    }
    else
    alert("Blood Group Not Matched")

    
    
  }
  
 else{
   alert('Blood Group Not Matched')
 }

}

  sendNotification() {
       for (const p of this.patientArr) {
        for (const u of this.userArr) {                                  
         if (p.patientBloodGroup === u.userBloodGroup) {
          alert('Blood Group Matched');
          this.count===1;
          break;
         }
         }
         if(this.count===0)
         {
         alert('This blood group is not avaliable');
         this.count=0;
         }
         }  
        
          
         }
        
         
        }
       
        
    





