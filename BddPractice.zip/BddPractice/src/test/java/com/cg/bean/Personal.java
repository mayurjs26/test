/**
 * 
 */
package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author mshinde2
 *
 */
public class Personal {
	
	@FindBy(id="firstName")
	WebElement firstName;
	
	@FindBy(id="lastName")
	WebElement lastName;
	
	@FindBy(id="email")
	WebElement email;

	@FindBy(id="address1")
	WebElement addressLine1;
	
	@FindBy(id="address2")
	WebElement addressLine2;
	
	@FindBy(id="city")
	WebElement city;
	
	@FindBy(id="state")
	WebElement state;
	
	@FindBy(id="mobileNo")
	WebElement contactNo;
	
	public Personal() {
	}

	public String getFirstName() {
		return this.firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return this.lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getAddressLine1() {
		return this.addressLine1.getAttribute("value");
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1.sendKeys(addressLine1);
	}

	public String getAddressLine2() {
		return this.addressLine2.getAttribute("value");
	}

	public void setAddressLine2(WebElement addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return this.city.getAttribute("value");
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public String getState() {
		return this.state.getAttribute("value");
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public String getContactNo() {
		return this.contactNo.getAttribute("value");
	}

	public void setContactNo(String contactNo) {
		this.contactNo.sendKeys(contactNo);
	}
	
	
}
