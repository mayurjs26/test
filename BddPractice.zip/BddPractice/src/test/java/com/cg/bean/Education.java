/**
 * 
 */
package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author mshinde2
 *
 */
public class Education {
	@FindBy(id="graduation")
	WebElement graduation;
	@FindBy(id="percent")
	WebElement percentage;
	@FindBy(id="pyear")
	WebElement passingYear;
	@FindBy(id="projectName")
	WebElement projectName;
	@FindBy(id="tech")
	WebElement technologies;
	@FindBy(id="other")
	WebElement otherTechnologies;

	public String getGraduation() {
		return this.graduation.getAttribute("value");
	}

	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}

	public String getPercentage() {
		return this.percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public String getPassingYear() {
		return this.passingYear.getAttribute("value");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public String getProjectName() {
		return this.projectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public String getTechnologies() {
		return this.technologies.getAttribute("value");
	}

	public void setTechnologies(String technologies) {
		this.technologies.sendKeys(technologies);
	}

	public String getOtherTechnologies() {
		return this.otherTechnologies.getAttribute("value");
	}

	public void setOtherTechnologies(String otherTechnologies) {
		this.otherTechnologies.sendKeys(otherTechnologies);
	}
	
	

}
