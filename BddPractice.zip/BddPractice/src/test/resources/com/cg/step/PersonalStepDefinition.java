/**
 * 
 */
package com.cg.step;

/**
 * @author mshinde2
 *
 */
public class PersonalStepDefinition {
	
	@Given("^User is on personal details page$")
	public void user_is_on_personal_details_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate page title$")
	public void validate_page_title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User Enters a First Name$")
	public void user_Enters_a_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate First Name$")
	public void validate_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User Enters a Last Name$")
	public void user_Enters_a_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Last Name$")
	public void validate_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User Enters a Email$")
	public void user_Enters_a_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Email$")
	public void validate_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User Enters a Contact No$")
	public void user_Enters_a_Contact_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Contact No$")
	public void validate_Contact_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Regex for Contact No$")
	public void validate_Regex_for_Contact_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User Enters a Address Line(\\d+)$")
	public void user_Enters_a_Address_Line(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Address Line(\\d+)$")
	public void validate_Address_Line(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User Selects a State$")
	public void user_Selects_a_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate State$")
	public void validate_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User Selects a City$")
	public void user_Selects_a_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate City$")
	public void validate_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters all valid details$")
	public void user_enters_all_valid_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Navigate to Education Details$")
	public void navigate_to_Education_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
