package com.capgemini.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "employee_details")
public class EmployeeDetails {

	@Id
	@Column(name = "employee_id")
	private int employeeId;
	
	@Column(name = "employee_firstname")
	private String firstName;
	
	@Column(name = "employee_lastname")
	private String lastName;
	
	@Column(name = "employee_gender")
	private String gender;
	
	@Column(name = "employee_contact")
	private String contact;
	
	@Column(name = "password")
	private String password;
	
	/*************RelationShip*****************/
	@OneToOne(mappedBy = "employee")
	private BorrowerDetails borrower;
	
}


