package com.capgemini.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "borrower_details")
public class BorrowerDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "borrower_id")
	private int borrowerId;
	
	@Column(name = "borrowed_from_date")
	private  String borrowedFromDate;
	
	@Column(name = "borrowed_to_date")
	private String borrowedToDate;
	
	@Column(name = "actual_return_date")
	private String actualReturnDate;
	
	/**************Relationship*******************/
	@OneToOne(mappedBy = "borrowedBook")
	@JoinColumn(name = "isbn")
	private BookDetails book;
	
	@OneToOne(mappedBy = "borrower")
	@JoinColumn(name = "employee_id")
	private EmployeeDetails employee;
	
}
