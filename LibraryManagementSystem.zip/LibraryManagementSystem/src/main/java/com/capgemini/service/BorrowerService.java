package com.capgemini.service;

public interface BorrowerService {

}
