package com.capgemini.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.EmployeeDetails;
import com.capgemini.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepo employeeRepo;

	public EmployeeDetails addEmployee(EmployeeDetails employee) {

		return employeeRepo.save(employee);

	}
	
	

}
