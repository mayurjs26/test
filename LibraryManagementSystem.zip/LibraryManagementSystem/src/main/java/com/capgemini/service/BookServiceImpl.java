package com.capgemini.service;

public class BookServiceImpl implements BookService{

}
